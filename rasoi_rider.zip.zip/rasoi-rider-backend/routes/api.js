const express = require('express');
const router = express.Router();
const Restaurant = require('../models/Restaurant');
const Dish = require('../models/Dish');
const Rider = require('../models/Rider');
const Order = require('../models/Order');

// Add a restaurant
router.post('/restaurants', async (req, res) => {
  const rest = await Restaurant.create(req.body);
  res.json(rest);
});

// Add a dish
router.post('/dishes', async (req, res) => {
  const dish = await Dish.create(req.body);
  res.json(dish);
});

// Register a rider
router.post('/riders', async (req, res) => {
  const rider = await Rider.create(req.body);
  res.json(rider);
});

// Place an order
router.post('/orders', async (req, res) => {
  const order = await Order.create(req.body);
  res.json(order);
});

// Get all orders
router.get('/orders', async (req, res) => {
  const orders = await Order.find()
    .populate('dish restaurant rider');
  res.json(orders);
});

// Assign a rider to an order
router.put('/orders/:id/assign/:riderId', async (req, res) => {
  const { id, riderId } = req.params;
  const order = await Order.findById(id);
  const rider = await Rider.findById(riderId);
  if (!order || !rider || !rider.available) {
    return res.status(400).json({ error: 'Invalid order or rider' });
  }
  order.rider = rider;
  order.status = 'assigned';
  rider.available = false;
  await order.save();
  await rider.save();
  res.json(order);
});

// Mark as delivered
router.put('/orders/:id/deliver', async (req, res) => {
  const order = await Order.findById(req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });
  order.status = 'delivered';
  await order.save();
  if (order.rider) {
    const rider = await Rider.findById(order.rider);
    rider.available = true;
    await rider.save();
  }
  res.json(order);
});

module.exports = router;
