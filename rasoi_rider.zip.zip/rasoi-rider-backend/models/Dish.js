const mongoose = require('mongoose');
const DishSchema = new mongoose.Schema({
  restaurant: { type: mongoose.Schema.Types.ObjectId, ref: 'Restaurant' },
  name: String,
  price: Number
});
module.exports = mongoose.model('Dish', DishSchema);
