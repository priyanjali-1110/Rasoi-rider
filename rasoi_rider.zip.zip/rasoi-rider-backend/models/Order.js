const mongoose = require('mongoose');
const OrderSchema = new mongoose.Schema({
  customerName: String,
  dish: { type: mongoose.Schema.Types.ObjectId, ref: 'Dish' },
  restaurant: { type: mongoose.Schema.Types.ObjectId, ref: 'Restaurant' },
  rider: { type: mongoose.Schema.Types.ObjectId, ref: 'Rider', default: null },
  status: { type: String, enum: ['placed','assigned','delivered'], default: 'placed' }
});
module.exports = mongoose.model('Order', OrderSchema);
