const mongoose = require('mongoose');
const RiderSchema = new mongoose.Schema({
  name: String,
  currentLocation: String,
  available: { type: Boolean, default: true }
});
module.exports = mongoose.model('Rider', RiderSchema);
